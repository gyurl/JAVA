package step5;

public class PersonTest {
	
	public static void main(String[] args) {
		//PhoneBookManager manager = new PhoneBookManager();
		//PhoneBookManager m2 = new PhoneBookManager();
		PhoneBookManager manager = PhoneBookManager.getInstance();
		//PhoneBookManager m2 = PhoneBookManager.getInstance();
		
		int choice=0;
		
		while(true) {
			MenuViewer.showMenu();
			choice = Integer.parseInt(MenuViewer.sc.nextLine());
			
			switch(choice) {
			case 1:
				manager.inputData();
				break;
			case 2:
				manager.display();
				break;
			case 3:     //��ȸ
				manager.searchData();
				break;
			case 4:		//����
				manager.updateData();
				break;
			case 5:		//����
				manager.deleteData();
				break;
			case 7:
				System.out.println("���α׷� �����մϴ�.");
				return;
			} //switch end
		} //while end
	} //main end
} // class end
