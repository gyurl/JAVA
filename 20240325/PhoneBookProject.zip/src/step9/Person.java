package step9;

import java.io.Serializable;

public class Person implements Serializable{
	//�̸�, ����, �������
	String name;
	String phoneNumber;
	String birthday;
	
	Person(){
		this.name="�ƹ���";
		this.phoneNumber="000-0000-0000";
		this.birthday = "9999-99-99";
	}
	
	Person(String name, String phoneNumber, String birthday) {
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.birthday = birthday;
	}

	void showInfo() {
		System.out.printf("%s : %s : %s%n", name, phoneNumber,birthday);
	}

	@Override
	public int hashCode() {
		return name.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Person) {
			Person tmp = (Person)obj;
			return name.equals(tmp.name);
		}
		return false;
	}
}
