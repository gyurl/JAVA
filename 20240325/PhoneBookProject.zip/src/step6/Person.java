package step6;

public class Person {
	//�̸�, ����, �������
	String name;
	String phoneNumber;
	String birthday;
	
	Person(){
		this.name="�ƹ���";
		this.phoneNumber="000-0000-0000";
		this.birthday = "9999-99-99";
	}
	
	Person(String name, String phoneNumber, String birthday) {
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.birthday = birthday;
	}

	void showInfo() {
		System.out.printf("%s : %s : %s%n", name, phoneNumber,birthday);
	}
	
}
