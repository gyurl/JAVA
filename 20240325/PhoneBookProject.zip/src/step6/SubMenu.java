package step6;

public interface SubMenu {
	int NORMAL=1, UNIV=2, COMPANY=3;
}
