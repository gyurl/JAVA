package step6;

public class PersonTest {
	
	public static void main(String[] args) {
		//PhoneBookManager manager = new PhoneBookManager();
		//PhoneBookManager m2 = new PhoneBookManager();
		PhoneBookManager manager = PhoneBookManager.getInstance();
		//PhoneBookManager m2 = PhoneBookManager.getInstance();
		
		int choice=0;
		
		while(true) {
			MenuViewer.showMenu();
			choice = Integer.parseInt(MenuViewer.sc.nextLine());
			
			
			switch(choice) {
			case MainMenu.INPUT:
				manager.inputData();
				break;
			case MainMenu.DISPAY_ALL:
				manager.display();
				break;
			case MainMenu.SEARCH:     
				manager.searchData();
				break;
			case MainMenu.UPDATE:		
				manager.updateData();
				break;
			case MainMenu.DELETE:		
				manager.deleteData();
				break;
			case MainMenu.EXIT:
				System.out.println("���α׷� �����մϴ�.");
				return;
			} //switch end
		} //while end
	} //main end
} // class end
