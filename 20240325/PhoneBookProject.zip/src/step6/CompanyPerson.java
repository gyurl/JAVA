package step6;

public class CompanyPerson extends Person {
	String company;
	
	CompanyPerson(String name, String phoneNumber, String birthday, String company){
		super(name, phoneNumber, birthday);
		this.company = company;
	}
	@Override
	void showInfo() {
		System.out.printf("%s : %s : %s : %s%n", name, phoneNumber,birthday, company);
	}
	
}
