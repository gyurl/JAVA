package step6;

public interface MainMenu {
	int INPUT=1, DISPAY_ALL=2, SEARCH =3, UPDATE=4, DELETE=5, EXIT=7;
}
