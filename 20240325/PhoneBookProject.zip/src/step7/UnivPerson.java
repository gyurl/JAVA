package step7;

public class UnivPerson extends Person {
	int grade;

	UnivPerson(String name, String phoneNumber, String birthday, int grade){
//		this.name = name;
//		this.phoneNumber = phoneNumber;
//		this.birthday = birthday;
		super(name, phoneNumber, birthday);
		this.grade = grade;
	}
	
	@Override
	void showInfo() {
		System.out.printf("%s : %s : %s : %d%n", name, phoneNumber,birthday,grade);
	}
	
}
