package step2;

import java.util.Scanner;

public class PersonTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
				
		System.out.print("�̸��� �Է� ==> ");
		String name = sc.nextLine();
		System.out.print("������ �Է� ==> ");
		String phoneNumber = sc.nextLine();
		System.out.print("������ �Է� ==>");
		String birthday = sc.nextLine();
		
		Person p1 = new Person();
		Person p2 = new Person(name, phoneNumber, birthday);
		p1.showInfo();
		p2.showInfo();
		
	}

}
